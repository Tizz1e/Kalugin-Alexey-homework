﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void b1_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            label.Content += btn.Content.ToString();
        }

        private void erase(object sender, RoutedEventArgs e)
        {
            label.Content = "";
        }

        private void check(object sender, RoutedEventArgs e)
        {
            if (label.Content.ToString() == "54321")
            {
                b1.IsEnabled = false;
                b2.IsEnabled = false;
                b3.IsEnabled = false;
                b4.IsEnabled = false;
                b5.IsEnabled = false;
                b6.IsEnabled = false;
                b7.IsEnabled = false;
                b8.IsEnabled = false;
                b9.IsEnabled = false;
                b0.IsEnabled = false;
                bc.IsEnabled = false;
                be.IsEnabled = false;
                label.IsEnabled = false;
            }
            else
            {
                label.Content = "";
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (label.IsEnabled)
            {
                if (e.Key == Key.D0) label.Content += "0";
                if (e.Key == Key.D1) label.Content += "1";
                if (e.Key == Key.D2) label.Content += "2";
                if (e.Key == Key.D3) label.Content += "3";
                if (e.Key == Key.D4) label.Content += "4";
                if (e.Key == Key.D5) label.Content += "5";
                if (e.Key == Key.D6) label.Content += "6";
                if (e.Key == Key.D7) label.Content += "7";
                if (e.Key == Key.D8) label.Content += "8";
                if (e.Key == Key.D9) label.Content += "9";
            }
         
        }
    }
}
